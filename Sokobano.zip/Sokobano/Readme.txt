This Sokoban was programmed in March 2009 by Martin Tschirsich, Artem Vovk, Shuo Yang, Zijad Maksuti.

Menu skybox (skybox_02) is (C) Aftas Ardem (ardemdoem@gmail.com)
Level sets are (C) by Thinking Rabbit Inc., Francois Marques, Ferdinand Tschirsich, Eric F. Tchong, David W. Skinner & the GDI1-Team (see also http://www.sourcecode.se/sokoban/levels.php)

Keyboard shortcuts:

n               Restart Game
u, z, backspace Undo
r, y            Redo
left            Move
right           "
up              "
down            "

c       Toggle 90� fixed / free camera
+, w    Zoom in
-, s    Zoom out
q       Rotate left
e       Rotate right


Sokobano Version 1.0.3