package gdi1sokoban.graphic.base;

import gdi1sokoban.graphic.DisplayList;

public class Mesh extends DisplayList {

	public Mesh(int displayList) {
		super(displayList);
	}

	public void finalize() throws Throwable {
		super.finalize();
	}
}
