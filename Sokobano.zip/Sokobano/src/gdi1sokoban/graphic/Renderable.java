package gdi1sokoban.graphic;

public interface Renderable {
	public void render();
}
