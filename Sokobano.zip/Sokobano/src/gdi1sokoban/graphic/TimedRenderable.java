package gdi1sokoban.graphic;

public interface TimedRenderable extends Renderable {
	public void render(long time);
}
