package gdi1sokoban.gui.event;

public interface MouseListener {
	
	abstract boolean mouseEvent(MouseEvent event);
}
