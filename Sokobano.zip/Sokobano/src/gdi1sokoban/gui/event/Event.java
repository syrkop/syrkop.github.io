package gdi1sokoban.gui.event;

public class Event {

}
