package gdi1sokoban.gui.event;

public interface ActionListener {
	
	abstract void actionEvent(ActionEvent event);
}
