package gdi1sokoban.gui.event;

public interface KeyboardListener {
	
	abstract boolean keyboardEvent(KeyboardEvent event);
}
