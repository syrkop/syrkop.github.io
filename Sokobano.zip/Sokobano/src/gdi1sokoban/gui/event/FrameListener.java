package gdi1sokoban.gui.event;

public interface FrameListener {
	
	abstract boolean frameEvent(FrameEvent event);
}
