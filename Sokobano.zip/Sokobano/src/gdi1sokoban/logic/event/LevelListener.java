package gdi1sokoban.logic.event;

public interface LevelListener {
	public void event(LevelEvent event);
}
