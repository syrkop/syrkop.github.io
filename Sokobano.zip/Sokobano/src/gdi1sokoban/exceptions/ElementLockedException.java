package gdi1sokoban.exceptions;

/**
 * Checks level for elements that are locked in walls
 * @author Stalker
 *
 */
public class ElementLockedException extends LevelFormatException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6299740907369339051L;
	

}

