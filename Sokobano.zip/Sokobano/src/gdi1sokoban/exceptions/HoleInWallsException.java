package gdi1sokoban.exceptions;

/**
 * There are some holes in wall 
 * @author Stalker
 *
 */
public class HoleInWallsException extends LevelFormatException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8520776310130257666L;
	

}

