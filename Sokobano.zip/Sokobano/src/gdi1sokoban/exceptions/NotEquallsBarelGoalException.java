package gdi1sokoban.exceptions;


/**
 * NUmber of barrels are not equals the number of goals
 * @author Stalker
 *
 */
public class NotEquallsBarelGoalException extends LevelFormatException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7471328375047312388L;
	

}

