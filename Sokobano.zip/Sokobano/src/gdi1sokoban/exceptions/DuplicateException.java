package gdi1sokoban.exceptions;

public class DuplicateException extends Exception{
	
	public String toString(){
		return "An illegal duplicate was detected";
	}

}
