package gdi1sokoban.exceptions;

/**
 * Some elements are not in defined count
 * @author Stalker
 *
 */
public class LevelElementsNotCorrectException extends LevelFormatException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7145163131907512779L;

}

