package gdi1sokoban.exceptions;

/**
 * There is not a one worker on the level
 * @author Stalker
 *
 */
public class NotOneWorkerException extends LevelFormatException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -374148857772942847L;

}
