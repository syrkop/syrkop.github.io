package gdi1sokoban.exceptions;

/**
 * Format of the level isn't right
 * @author Stalker
 *
 */
public class LevelFormatException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7669086705358424911L;
	
	

}
