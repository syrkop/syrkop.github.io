package gdi1sokoban.exceptions;

/**
 * There are no barrels on the level
 * @author Stalker
 *
 */
public class NoBarelException extends LevelFormatException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1152767622872509351L;

}

